export const ID_COEFFICIENTS = 139;

export const FIELD_COEFFICIENTS = {
    MDF6mm: {
        fieldId: 'ufCrm33_1708830433',             // МДФ 6мм для МСП
        coefficientFieldId: 'ufCrm33_1708830698',  // Что входит в коэф. МДФ 6мм
    },
    MDF10mm: {
        fieldId: 'ufCrm33_1708830433',             // МДФ 6мм для МСП
        coefficientFieldId: 'ufCrm33_1708830698',  // Что входит в коэф. МДФ 6мм
    },
    MDF15mm: {
        fieldId: 'ufCrm33_1708830433',             // МДФ 6мм для МСП
        coefficientFieldId: 'ufCrm33_1708830698',  // Что входит в коэф. МДФ 6мм
    },
    MDF19mm: {
        fieldId: 'ufCrm33_1708830433',             // МДФ 6мм для МСП
        coefficientFieldId: 'ufCrm33_1708830698',  // Что входит в коэф. МДФ 6мм
    },
    MDF25mm: {
        fieldId: 'ufCrm33_1708830433',             // МДФ 6мм для МСП
        coefficientFieldId: 'ufCrm33_1708830698',  // Что входит в коэф. МДФ 6мм
    },
    PPU_EL: {
        fieldId: 'ufCrm33_1708830476',            // ППУ ЕЛ и Elax
        coefficientFieldId: 'ufCrm33_1708830738', // Что входит в коэф. ППУ
    },
    PPU_EL20mm: {
        fieldId: 'ufCrm33_1708830476',            // ППУ ЕЛ и Elax
        coefficientFieldId: 'ufCrm33_1708830738', // Что входит в коэф. ППУ
    },
    PPU_EL30mm: {
        fieldId: 'ufCrm33_1708830476',            // ППУ ЕЛ и Elax
        coefficientFieldId: 'ufCrm33_1708830738', // Что входит в коэф. ППУ
    },
    PPU_EL40mm: {
        fieldId: 'ufCrm33_1708830476',            // ППУ ЕЛ и Elax
        coefficientFieldId: 'ufCrm33_1708830738', // Что входит в коэф. ППУ
    },
    constantCosts: {
        fieldId: 'ufCrm33_1711595356',            // Постоянные затраты
        coefficientFieldId: 'ufCrm33_1711595374', // Что входит в постоянные затраты
    },
    plywood15mm: {
        fieldId: 'ufCrm33_1713685572',            // Фанера 15мм
        coefficientFieldId: 'ufCrm33_1713685652', // Что входит в коэфф Фанера 15мм
    },
    plywood3mm: {
        fieldId: 'ufCrm33_1713685670',            // Фанера 3мм
        coefficientFieldId: 'ufCrm33_1713685729', // Что входит в коэфф Фанера 03 мм
    },
    fiberboard: {
        fieldId: 'ufCrm33_1713685670',            // ДВП
        coefficientFieldId: 'ufCrm33_1713685729', // Что входит в коэфф ДВП
    },
    elecCardboard: {
        fieldId: 'ufCrm33_1734622134',            // Элек. картон
        coefficientFieldId: 'ufCrm33_1713685729', // Что входит в коэфф Элек. картон
    },
    // latexMemory: {
    //     fieldId: 'ufCrm33_1713685754',            // Латекс и Мемори
    //     coefficientFieldId: 'ufCrm33_1713685774', // Что входит в коэфф Латкс и Мемори
    // },
    Latex30mm: {
        fieldId: 'ufCrm33_1713685754',            // Латекс и Мемори
        coefficientFieldId: 'ufCrm33_1713685774', // Что входит в коэфф Латкс и Мемори
    },
    Memory50mm: {
        fieldId: 'ufCrm33_1713685754',            // Латекс и Мемори
        coefficientFieldId: 'ufCrm33_1713685774', // Что входит в коэфф Латкс и Мемори
    },
    workshopConstantCosts: {
        fieldId: 'ufCrm33_1713690241',            // Постоянные затраты цеха
        coefficientFieldId: 'ufCrm33_1713690271', // Что входит в постоянные затраты цеха
    },

    Fabric1Smart: {
        fieldId: 'ufCrm33_1714703414',            // Ткани
        coefficientFieldId: 'ufCrm33_1714703428', // Что входит в ткани
    },
    Fabric1: {
        fieldId: 'ufCrm33_1714703414',            // Ткани
        coefficientFieldId: 'ufCrm33_1714703428', // Что входит в ткани
    },
    Fabric2: {
        fieldId: 'ufCrm33_1714703414',            // Ткани
        coefficientFieldId: 'ufCrm33_1714703428', // Что входит в ткани
    },
    Fabric3: {
        fieldId: 'ufCrm33_1714703414',            // Ткани
        coefficientFieldId: 'ufCrm33_1714703428', // Что входит в ткани
    },
    markup: [
        'ufCrm33_1723443658',            // Наценка №1
        'ufCrm33_1723443712',            // Наценка №2
        'ufCrm33_1723443727',            // Наценка №3
        'ufCrm33_1723443743',            // Наценка №4
        'ufCrm33_1723443945',            // Наценка №5
        'ufCrm33_1723443956',            // Наценка №6
    ],     
    markupWorkshop: 'ufCrm33_1732255162' // Наценка Цех
};
